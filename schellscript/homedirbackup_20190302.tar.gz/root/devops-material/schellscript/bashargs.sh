#!/bin/bash
osname=$1
echo $osname
echo `uname -a`

